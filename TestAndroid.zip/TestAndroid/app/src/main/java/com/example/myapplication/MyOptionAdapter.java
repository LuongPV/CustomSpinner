package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import java.util.List;

public class MyOptionAdapter extends ArrayAdapter<MyOption> {
    private final Context context;
    private final List<MyOption> myOptions;

    public MyOptionAdapter(Context context, List<MyOption> myOptions) {
        super(context, R.layout.spinner_item_top, myOptions);
        this.context = context;
        this.myOptions = myOptions;
    }

    @Override
    public View getDropDownView(int position, View convertView, @NonNull ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }

    @SuppressLint("ViewHolder")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        TextView textView = (TextView) inflater.inflate(R.layout.spinner_item_top, parent, false);
        textView.setText(myOptions.get(position).getName());
        return textView;
    }

    public View getCustomView(int position, View convertView, ViewGroup parent) {
        if (position == 0) {

        }
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row = inflater.inflate(R.layout.spinner_item_dropdown, parent, false);
        TextView textView = (TextView) row.findViewById(R.id.tv);
        MyOption myOption = myOptions.get(position);
        textView.setText(myOption.getName());
        Drawable drawable;
        int color;
        if (myOption.getSelected()) {
            drawable = ContextCompat.getDrawable(context, R.drawable.bg_item_pressed);
            color = R.color.red;
        } else {
            drawable = ContextCompat.getDrawable(context, R.drawable.bg_item);
            color = R.color.gray;
        }
        textView.setBackground(drawable);
        textView.setTextColor(ContextCompat.getColor(context, color));
        row.setOnTouchListener(new View.OnTouchListener() {
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                for (MyOption option : myOptions) {
                    boolean isSelected = option.getName().equals(myOption.getName());
                    option.setSelected(isSelected);
                }
                return false;
            }
        });
        return row;
    }
}