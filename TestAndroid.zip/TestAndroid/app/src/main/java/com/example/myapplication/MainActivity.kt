package com.example.myapplication

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.e("TAG", "onCreate loaded")

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val spinner: Spinner = findViewById(R.id.planets_spinner)

        val data = listOf(
            "data1", "data2", "data3", "data4", "data5"
        )

        val dataOption = data.mapIndexed { index, dataItem ->
            MyOption(dataItem, index == 0)
        }

        val adapter = MyOptionAdapter(this, dataOption)
        spinner.adapter = adapter

        val layout = findViewById<View>(R.id.layout)
        layout.setOnClickListener {
            spinner.performClick()
        }



        setSupportActionBar(binding.toolbar)
    }
}