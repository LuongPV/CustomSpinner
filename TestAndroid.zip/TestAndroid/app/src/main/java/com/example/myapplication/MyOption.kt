package com.example.myapplication

data class MyOption(
    var name: String,
    var selected: Boolean
)